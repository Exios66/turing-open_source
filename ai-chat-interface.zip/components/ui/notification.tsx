"use client"

import React, { useEffect, useState } from "react"
import { AnimatePresence, motion } from "framer-motion"
import { X, CheckCircle, AlertCircle, InfoIcon } from "lucide-react"
import { cn } from "@/lib/utils"

export type NotificationType = "success" | "error" | "info" | "warning"

export interface NotificationProps {
  id: string
  title: string
  message?: string
  type: NotificationType
  duration?: number
  onClose?: (id: string) => void
}

export const Notification = ({ id, title, message, type = "info", duration = 5000, onClose }: NotificationProps) => {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    if (duration > 0) {
      const timer = setTimeout(() => {
        setIsVisible(false)
      }, duration)

      return () => clearTimeout(timer)
    }
  }, [duration])

  const handleClose = () => {
    setIsVisible(false)
    if (onClose) {
      setTimeout(() => onClose(id), 300) // Wait for animation to complete
    }
  }

  const getIcon = () => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "error":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case "warning":
        return <AlertCircle className="h-5 w-5 text-yellow-500" />
      case "info":
      default:
        return <InfoIcon className="h-5 w-5 text-blue-500" />
    }
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className={cn(
            "w-full max-w-sm rounded-lg border bg-background p-4 shadow-lg",
            type === "success" && "border-green-200",
            type === "error" && "border-red-200",
            type === "warning" && "border-yellow-200",
            type === "info" && "border-blue-200",
          )}
        >
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0">{getIcon()}</div>
            <div className="flex-1">
              <h3 className="font-medium text-foreground">{title}</h3>
              {message && <p className="mt-1 text-sm text-muted-foreground">{message}</p>}
            </div>
            <button
              onClick={handleClose}
              className="flex-shrink-0 rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

interface NotificationsProviderProps {
  children: React.ReactNode
}

interface NotificationContextType {
  showNotification: (notification: Omit<NotificationProps, "id">) => string
  closeNotification: (id: string) => void
}

const NotificationContext = React.createContext<NotificationContextType | undefined>(undefined)

export const NotificationsProvider = ({ children }: NotificationsProviderProps) => {
  const [notifications, setNotifications] = useState<NotificationProps[]>([])

  const showNotification = (notification: Omit<NotificationProps, "id">) => {
    const id = `notification-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`
    setNotifications((prev) => [...prev, { ...notification, id }])
    return id
  }

  const closeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notification) => notification.id !== id))
  }

  return (
    <NotificationContext.Provider value={{ showNotification, closeNotification }}>
      {children}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2">
        {notifications.map((notification) => (
          <Notification key={notification.id} {...notification} onClose={closeNotification} />
        ))}
      </div>
    </NotificationContext.Provider>
  )
}

export const useNotifications = () => {
  const context = React.useContext(NotificationContext)
  if (context === undefined) {
    throw new Error("useNotifications must be used within a NotificationsProvider")
  }
  return context
}

