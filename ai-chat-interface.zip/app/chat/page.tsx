import AppLayout from "../app-layout"
import ChatInterface from "../../ChatInterface"
import ErrorBoundary from "@/components/error-boundary"

export default function ChatPage() {
  return (
    <AppLayout>
      <ErrorBoundary>
        <ChatInterface />
      </ErrorBoundary>
    </AppLayout>
  )
}

