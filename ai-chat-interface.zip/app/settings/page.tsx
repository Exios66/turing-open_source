"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useApiProviders, type ApiProvider, type ApiConfig } from "@/lib/api-providers"
import { useNotifications } from "@/components/ui/notification"
import { logger } from "@/lib/logger"
import { ExternalLink, Check, AlertCircle, RefreshCw } from "lucide-react"
import { useRouting } from "@/lib/routing"
import AppLayout from "../app-layout"
import ErrorBoundary from "@/components/error-boundary"
import { Progress } from "@/components/ui/progress"

export default function SettingsPage() {
  const { providers, configs, setConfig, setActiveProvider, activeProvider, hasAnyConfig } = useApiProviders()
  const { showNotification } = useNotifications()
  const { navigate } = useRouting()
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState<ApiProvider>(activeProvider)

  // Set the active tab to the active provider when the component mounts
  useEffect(() => {
    setActiveTab(activeProvider)
  }, [activeProvider])

  const handleSaveConfig = async (provider: ApiProvider, config: ApiConfig) => {
    try {
      setIsLoading(true)

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 800))

      setConfig(provider, config)
      showNotification({
        type: "success",
        title: "Settings saved",
        message: `${providers[provider].name} configuration has been saved.`,
      })
      logger.info("API provider config saved", { provider })

      // If this is the first config, set it as active
      if (!hasAnyConfig) {
        setActiveProvider(provider)
      }
    } catch (error) {
      logger.error("Failed to save API provider config", {
        provider,
        error: error instanceof Error ? error.message : String(error),
        errorCode: "CONFIG_SAVE_ERROR",
      })
      showNotification({
        type: "error",
        title: "Failed to save settings",
        message: "An error occurred while saving your settings.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleActivateProvider = (provider: ApiProvider) => {
    try {
      setActiveProvider(provider)
      showNotification({
        type: "success",
        title: "Provider activated",
        message: `${providers[provider].name} is now the active provider.`,
      })
    } catch (error) {
      logger.error("Failed to activate provider", {
        provider,
        error: error instanceof Error ? error.message : String(error),
        errorCode: "PROVIDER_ACTIVATION_ERROR",
      })
      showNotification({
        type: "error",
        title: "Failed to activate provider",
        message: "An error occurred while activating the provider.",
      })
    }
  }

  const handleTestConfig = async (provider: ApiProvider, config: ApiConfig) => {
    try {
      setIsLoading(true)
      showNotification({
        type: "info",
        title: "Testing connection",
        message: `Testing connection to ${providers[provider].name}...`,
      })

      // In a real app, you would make an API call to test the connection
      await new Promise((resolve) => setTimeout(resolve, 1500))

      showNotification({
        type: "success",
        title: "Connection successful",
        message: `Successfully connected to ${providers[provider].name}.`,
      })
    } catch (error) {
      logger.error("Failed to test API provider connection", {
        provider,
        error: error instanceof Error ? error.message : String(error),
        errorCode: "CONNECTION_TEST_ERROR",
      })
      showNotification({
        type: "error",
        title: "Connection failed",
        message: `Failed to connect to ${providers[provider].name}.`,
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleBackToChat = () => {
    navigate("/chat")
  }

  return (
    <AppLayout>
      <ErrorBoundary>
        <div className="container py-8 max-w-4xl">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">API Settings</h1>
              <p className="text-muted-foreground">Configure your AI providers</p>
            </div>
            <Button onClick={handleBackToChat}>Back to Chat</Button>
          </div>

          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as ApiProvider)}>
            <TabsList className="grid grid-cols-3 md:grid-cols-6 mb-4">
              {Object.entries(providers).map(([id, provider]) => (
                <TabsTrigger key={id} value={id} className="relative">
                  {provider.name}
                  {configs[id as ApiProvider] && (
                    <span className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full" />
                  )}
                </TabsTrigger>
              ))}
            </TabsList>

            {Object.entries(providers).map(([id, provider]) => {
              const providerKey = id as ApiProvider
              return (
                <TabsContent key={id} value={id}>
                  <ProviderConfigForm
                    provider={providerKey}
                    providerInfo={provider}
                    initialConfig={configs[providerKey]}
                    isActive={activeProvider === providerKey}
                    isLoading={isLoading}
                    onSave={handleSaveConfig}
                    onActivate={handleActivateProvider}
                    onTest={handleTestConfig}
                  />
                </TabsContent>
              )
            })}
          </Tabs>
        </div>
      </ErrorBoundary>
    </AppLayout>
  )
}

interface ProviderConfigFormProps {
  provider: ApiProvider
  providerInfo: any
  initialConfig: ApiConfig | null
  isActive: boolean
  isLoading: boolean
  onSave: (provider: ApiProvider, config: ApiConfig) => void
  onActivate: (provider: ApiProvider) => void
  onTest: (provider: ApiProvider, config: ApiConfig) => void
}

function ProviderConfigForm({
  provider,
  providerInfo,
  initialConfig,
  isActive,
  isLoading,
  onSave,
  onActivate,
  onTest,
}: ProviderConfigFormProps) {
  const [config, setConfig] = useState<Partial<ApiConfig>>(
    initialConfig || {
      provider,
      apiKey: "",
      baseUrl: providerInfo.defaultBaseUrl,
      defaultModel: providerInfo.defaultModels[0],
    },
  )

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setConfig((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!config.apiKey && providerInfo.requiresApiKey) {
      return
    }
    onSave(provider, {
      provider,
      apiKey: config.apiKey || "",
      baseUrl: config.baseUrl,
      defaultModel: config.defaultModel || providerInfo.defaultModels[0],
    })
  }

  const handleTest = () => {
    if (!config.apiKey && providerInfo.requiresApiKey) {
      return
    }
    onTest(provider, {
      provider,
      apiKey: config.apiKey || "",
      baseUrl: config.baseUrl,
      defaultModel: config.defaultModel || providerInfo.defaultModels[0],
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{providerInfo.name} Configuration</CardTitle>
        <CardDescription>
          {providerInfo.description}
          <a
            href={providerInfo.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center ml-2 text-blue-500 hover:underline"
          >
            Learn more <ExternalLink className="h-3 w-3 ml-1" />
          </a>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {providerInfo.requiresApiKey && (
            <div className="space-y-2">
              <Label htmlFor={`${provider}-api-key`}>
                {providerInfo.apiKeyName}
                <a
                  href={providerInfo.apiKeyLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center ml-2 text-xs text-blue-500 hover:underline"
                >
                  Get API key <ExternalLink className="h-3 w-3 ml-1" />
                </a>
              </Label>
              <Input
                id={`${provider}-api-key`}
                name="apiKey"
                type="password"
                value={config.apiKey || ""}
                onChange={handleChange}
                placeholder={`Enter your ${providerInfo.name} API key`}
                required={providerInfo.requiresApiKey}
                disabled={isLoading}
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor={`${provider}-base-url`}>Base URL (Optional)</Label>
            <Input
              id={`${provider}-base-url`}
              name="baseUrl"
              value={config.baseUrl || ""}
              onChange={handleChange}
              placeholder={providerInfo.defaultBaseUrl}
              disabled={isLoading}
            />
            <p className="text-xs text-muted-foreground">
              Leave empty to use the default: {providerInfo.defaultBaseUrl}
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor={`${provider}-default-model`}>Default Model</Label>
            <select
              id={`${provider}-default-model`}
              name="defaultModel"
              value={config.defaultModel || providerInfo.defaultModels[0]}
              onChange={handleChange}
              className="w-full px-3 py-2 border rounded-md bg-background"
              disabled={isLoading}
            >
              {providerInfo.defaultModels.map((model: string) => (
                <option key={model} value={model}>
                  {model}
                </option>
              ))}
            </select>
          </div>

          {initialConfig && (
            <div className="flex items-center mt-4 p-2 bg-green-50 dark:bg-green-900/20 rounded-md">
              <Check className="h-5 w-5 text-green-500 mr-2" />
              <p className="text-sm text-green-700 dark:text-green-300">Configuration saved</p>
            </div>
          )}

          {!providerInfo.supportsStreaming && (
            <div className="flex items-center mt-4 p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded-md">
              <AlertCircle className="h-5 w-5 text-yellow-500 mr-2" />
              <p className="text-sm text-yellow-700 dark:text-yellow-300">
                This provider does not support streaming responses
              </p>
            </div>
          )}

          {isLoading && (
            <div className="mt-4">
              <Progress value={45} className="h-1" />
              <p className="text-sm text-muted-foreground mt-2 text-center">Processing request...</p>
            </div>
          )}
        </form>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div className="flex gap-2">
          <Button type="submit" onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              "Save Configuration"
            )}
          </Button>
          <Button type="button" variant="outline" onClick={handleTest} disabled={isLoading}>
            Test Connection
          </Button>
        </div>

        {initialConfig && !isActive && (
          <Button type="button" variant="secondary" onClick={() => onActivate(provider)} disabled={isLoading}>
            Set as Active Provider
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

