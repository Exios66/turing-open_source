import AppLayout from "../app-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ExternalLink, MessageSquare, Settings, Key, AlertTriangle, HelpCircle } from "lucide-react"
import Link from "next/link"

export default function HelpPage() {
  return (
    <AppLayout>
      <div className="container py-8 max-w-4xl">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Help & Documentation</h1>
          <p className="text-muted-foreground">Learn how to use the AI Chat Interface</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                Using the Chat Interface
              </CardTitle>
              <CardDescription>Learn how to interact with the AI assistant</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>
                  <strong>Starting a conversation:</strong> Type your message in the input field and press Enter or
                  click the Send button.
                </li>
                <li>
                  <strong>Voice input:</strong> Click the microphone icon to use voice input (if supported by your
                  browser).
                </li>
                <li>
                  <strong>Message actions:</strong> Hover over messages to see options like copy, download, and
                  feedback.
                </li>
                <li>
                  <strong>Stopping generation:</strong> Click "Stop generating" to halt the AI's response.
                </li>
              </ul>
              <Link href="/chat" className="text-blue-500 hover:underline mt-4 inline-flex items-center">
                Go to Chat <ExternalLink className="h-3 w-3 ml-1" />
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="h-5 w-5 mr-2" />
                Configuring API Providers
              </CardTitle>
              <CardDescription>Set up and manage your AI providers</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>
                  <strong>Adding a provider:</strong> Go to Settings, select a provider tab, and enter your API key.
                </li>
                <li>
                  <strong>Changing models:</strong> Each provider offers different models you can select from the
                  dropdown.
                </li>
                <li>
                  <strong>Testing connection:</strong> Use the "Test Connection" button to verify your API key works.
                </li>
                <li>
                  <strong>Switching providers:</strong> Click "Set as Active Provider" to change which AI service is
                  used.
                </li>
              </ul>
              <Link href="/settings" className="text-blue-500 hover:underline mt-4 inline-flex items-center">
                Go to Settings <ExternalLink className="h-3 w-3 ml-1" />
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Key className="h-5 w-5 mr-2" />
                Getting API Keys
              </CardTitle>
              <CardDescription>How to obtain API keys for different providers</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>
                  <strong>OpenAI:</strong>{" "}
                  <a
                    href="https://platform.openai.com/api-keys"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline"
                  >
                    Visit OpenAI API Keys page
                  </a>
                </li>
                <li>
                  <strong>Anthropic:</strong>{" "}
                  <a
                    href="https://console.anthropic.com/settings/keys"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline"
                  >
                    Visit Anthropic Console
                  </a>
                </li>
                <li>
                  <strong>Google AI:</strong>{" "}
                  <a
                    href="https://ai.google.dev/tutorials/setup"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline"
                  >
                    Visit Google AI Developer page
                  </a>
                </li>
                <li>
                  <strong>Other providers:</strong> Visit the Settings page for links to all supported providers.
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="h-5 w-5 mr-2" />
                Troubleshooting
              </CardTitle>
              <CardDescription>Common issues and how to resolve them</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>
                  <strong>API errors:</strong> Verify your API key is correct and has sufficient permissions.
                </li>
                <li>
                  <strong>Connection issues:</strong> Check your internet connection and try again.
                </li>
                <li>
                  <strong>Rate limiting:</strong> Some providers have usage limits. Wait a few minutes and try again.
                </li>
                <li>
                  <strong>Browser compatibility:</strong> Ensure you're using a modern browser like Chrome, Firefox, or
                  Safari.
                </li>
              </ul>
              <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-md flex items-center">
                <HelpCircle className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0" />
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  For additional help, contact support at support@example.com
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  )
}

