"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  LayoutGrid,
  Settings,
  Users,
  SettingsIcon as Functions,
  Layers,
  Eye,
  BarChart2,
  X,
  Save,
  Download,
  FileText,
  HelpCircle,
  MessageSquare,
} from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { useRouting } from "@/lib/routing"
import ErrorBoundary from "@/components/error-boundary"
import { logger } from "@/lib/logger"
import { usePathname } from "next/navigation"
import Link from "next/link"

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [activeTab, setActiveTab] = useState<string>("chat")
  const [activeDetailTab, setActiveDetailTab] = useState<string>("actions")
  const { navigate } = useRouting()

  // Set the active tab based on the current pathname
  useEffect(() => {
    if (pathname.includes("/settings")) {
      setActiveTab("settings")
    } else if (pathname.includes("/help")) {
      setActiveTab("help")
    } else {
      setActiveTab("chat")
    }
  }, [pathname])

  const handleMenuClick = (tab: string) => {
    setActiveTab(tab)

    // Handle navigation based on tab
    if (tab === "settings") {
      navigate("/settings")
      logger.info("Navigated to settings page", { timestamp: new Date().toISOString() })
    } else if (tab === "help") {
      navigate("/help")
      logger.info("Navigated to help page", { timestamp: new Date().toISOString() })
    } else if (tab === "chat") {
      navigate("/chat")
      logger.info("Navigated to chat page", { timestamp: new Date().toISOString() })
    } else {
      toast({
        title: `${tab.charAt(0).toUpperCase() + tab.slice(1)} selected`,
        description: `You've navigated to the ${tab} section`,
      })
    }
  }

  const handleDetailTabClick = (tab: string) => {
    setActiveDetailTab(tab)
  }

  const handleSaveConversation = () => {
    try {
      toast({
        title: "Conversation saved",
        description: "Your conversation has been saved successfully",
      })
      logger.info("Conversation saved", { timestamp: new Date().toISOString() })
    } catch (error) {
      logger.error("Failed to save conversation", {
        error: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString(),
      })
      toast({
        title: "Error",
        description: "Failed to save conversation",
        variant: "destructive",
      })
    }
  }

  const handleCloseConversation = () => {
    try {
      toast({
        title: "Conversation closed",
        description: "You can start a new conversation now",
      })
      logger.info("Conversation closed", { timestamp: new Date().toISOString() })
    } catch (error) {
      logger.error("Failed to close conversation", {
        error: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString(),
      })
      toast({
        title: "Error",
        description: "Failed to close conversation",
        variant: "destructive",
      })
    }
  }

  return (
    <ErrorBoundary>
      <div className="flex h-screen bg-background">
        {/* Sidebar */}
        <div className="w-64 border-r bg-muted/10">
          <div className="p-4 border-b">
            <Link href="/" className="flex items-center gap-2">
              <div className="h-6 w-6 rounded-full bg-primary" />
              <span className="font-semibold">GenerativeAgent</span>
            </Link>
          </div>
          <ScrollArea className="h-[calc(100vh-64px)]">
            <div className="space-y-4 p-4">
              <nav className="space-y-2">
                <Button
                  variant={activeTab === "chat" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => handleMenuClick("chat")}
                >
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Chat
                </Button>
                <Button
                  variant={activeTab === "tasks" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => handleMenuClick("tasks")}
                >
                  <LayoutGrid className="mr-2 h-4 w-4" />
                  Tasks
                </Button>
                <Button
                  variant={activeTab === "functions" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => handleMenuClick("functions")}
                >
                  <Functions className="mr-2 h-4 w-4" />
                  Functions
                </Button>
                <Button
                  variant={activeTab === "integrations" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => handleMenuClick("integrations")}
                >
                  <Layers className="mr-2 h-4 w-4" />
                  Integrations
                </Button>
                <Button
                  variant={activeTab === "users" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => handleMenuClick("users")}
                >
                  <Users className="mr-2 h-4 w-4" />
                  Users
                </Button>
                <Button
                  variant={activeTab === "settings" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => handleMenuClick("settings")}
                >
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </Button>
              </nav>
              <div className="pt-4 border-t">
                <Button
                  variant={activeTab === "preview" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => handleMenuClick("preview")}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  Live preview
                </Button>
                <Button
                  variant={activeTab === "performance" ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => handleMenuClick("performance")}
                >
                  <BarChart2 className="mr-2 h-4 w-4" />
                  Performance
                </Button>
                <Button
                  variant={activeTab === "help" ? "secondary" : "ghost"}
                  className="w-full justify-start mt-2"
                  onClick={() => handleMenuClick("help")}
                >
                  <HelpCircle className="mr-2 h-4 w-4" />
                  Help & Support
                </Button>
              </div>
            </div>
          </ScrollArea>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex">
          <div className="flex-1 flex flex-col">
            {/* Header */}
            <header className="h-14 border-b px-4 flex items-center justify-between">
              <h1 className="text-sm font-medium">
                {activeTab === "chat" && "Chat Conversation"}
                {activeTab === "settings" && "API Settings"}
                {activeTab === "help" && "Help & Documentation"}
                {!["chat", "settings", "help"].includes(activeTab) && "GenerativeAgent"}
              </h1>
              <div className="flex items-center gap-2">
                {activeTab === "chat" && (
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleSaveConversation}
                      className="flex items-center gap-1"
                    >
                      <Save className="h-4 w-4 mr-1" />
                      Save conversation
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={handleCloseConversation}>
                      <X className="h-4 w-4" />
                    </Button>
                  </>
                )}
              </div>
            </header>
            {children}
          </div>

          {/* Right Panel */}
          {activeTab === "chat" && (
            <div className="w-80 border-l">
              <div className="h-14 border-b px-4 flex items-center">
                <h2 className="font-medium">Conversation details</h2>
              </div>
              <div className="p-4">
                <div className="flex gap-4 border-b pb-4">
                  <Button
                    variant={activeDetailTab === "actions" ? "secondary" : "ghost"}
                    size="sm"
                    className="rounded-full"
                    onClick={() => handleDetailTabClick("actions")}
                  >
                    Actions
                  </Button>
                  <Button
                    variant={activeDetailTab === "customer" ? "secondary" : "ghost"}
                    size="sm"
                    className="rounded-full"
                    onClick={() => handleDetailTabClick("customer")}
                  >
                    Customer
                  </Button>
                  <Button
                    variant={activeDetailTab === "settings" ? "secondary" : "ghost"}
                    size="sm"
                    className="rounded-full"
                    onClick={() => handleDetailTabClick("settings")}
                  >
                    Settings
                  </Button>
                </div>

                {activeDetailTab === "actions" && (
                  <div className="pt-4 space-y-3">
                    <h3 className="text-sm font-medium mb-2">Quick Actions</h3>
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <FileText className="mr-2 h-4 w-4" />
                      Generate summary
                    </Button>
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <Download className="mr-2 h-4 w-4" />
                      Export conversation
                    </Button>
                  </div>
                )}

                {activeDetailTab === "customer" && (
                  <div className="pt-4">
                    <h3 className="text-sm font-medium mb-2">Customer Information</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Name:</span>
                        <span>John Doe</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Account:</span>
                        <span>#12345</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Status:</span>
                        <span className="bg-green-100 text-green-800 px-2 py-0.5 rounded-full text-xs">Active</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last contact:</span>
                        <span>2 days ago</span>
                      </div>
                    </div>
                  </div>
                )}

                {activeDetailTab === "settings" && (
                  <div className="pt-4">
                    <h3 className="text-sm font-medium mb-2">Conversation Settings</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Auto-save</span>
                        <div className="relative inline-flex h-4 w-8 items-center rounded-full bg-muted transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary">
                          <span className="inline-block h-3 w-3 translate-x-4 rounded-full bg-primary-foreground transition-transform data-[state=unchecked]:translate-x-0.5"></span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Voice feedback</span>
                        <div className="relative inline-flex h-4 w-8 items-center rounded-full bg-primary transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=unchecked]:bg-muted">
                          <span className="inline-block h-3 w-3 translate-x-4 rounded-full bg-primary-foreground transition-transform data-[state=unchecked]:translate-x-0.5"></span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </ErrorBoundary>
  )
}

