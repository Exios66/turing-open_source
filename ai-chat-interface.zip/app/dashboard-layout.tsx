"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAppContext } from "@/context/app-context"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  LayoutGrid,
  Settings,
  Users,
  SettingsIcon as Functions,
  Layers,
  Eye,
  BarChart2,
  X,
  ChevronLeft,
  ChevronRight,
  Moon,
  Sun,
  Monitor,
  Menu,
} from "lucide-react"
import { AnimatePresence, motion } from "framer-motion"
import { useMediaQuery } from "@/hooks/use-media-query"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const {
    activeSection,
    setActiveSection,
    activePanel,
    setActivePanel,
    theme,
    setTheme,
    sidebarCollapsed,
    setSidebarCollapsed,
    activeConversation,
    saveConversation,
    closeConversation,
  } = useAppContext()

  const [mounted, setMounted] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const isMobile = useMediaQuery("(max-width: 768px)")

  // Prevent hydration mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const sidebarItems = [
    { icon: LayoutGrid, label: "Tasks", value: "tasks" },
    { icon: Functions, label: "Functions", value: "functions" },
    { icon: Layers, label: "Integrations", value: "integrations" },
    { icon: Users, label: "Users", value: "users" },
    { icon: Settings, label: "Settings", value: "settings" },
  ]

  const sidebarBottomItems = [
    { icon: Eye, label: "Live preview", value: "preview" },
    { icon: BarChart2, label: "Performance", value: "performance" },
  ]

  const handleSectionClick = (section: any) => {
    setActiveSection(section)
    if (isMobile) {
      setMobileMenuOpen(false)
    }
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Mobile menu button */}
      {isMobile && (
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-3 left-3 z-50 md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          <Menu className="h-5 w-5" />
        </Button>
      )}

      {/* Sidebar */}
      <AnimatePresence mode="wait">
        {((!isMobile && !sidebarCollapsed) || (isMobile && mobileMenuOpen)) && (
          <motion.div
            className={cn("fixed inset-y-0 left-0 z-40 bg-background border-r", isMobile ? "w-64" : "w-64")}
            initial={{ x: -320 }}
            animate={{ x: 0 }}
            exit={{ x: -320 }}
            transition={{ duration: 0.2, ease: "easeInOut" }}
          >
            <div className="p-4 border-b flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="h-6 w-6 rounded-full bg-primary" />
                <span className="font-semibold">GenerativeAgent</span>
              </div>
              {!isMobile && (
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSidebarCollapsed(true)}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
              )}
            </div>
            <ScrollArea className="h-[calc(100vh-64px)]">
              <div className="space-y-4 p-4">
                <nav className="space-y-2">
                  {sidebarItems.map((item) => (
                    <Button
                      key={item.value}
                      variant={activeSection === item.value ? "secondary" : "ghost"}
                      className="w-full justify-start"
                      onClick={() => handleSectionClick(item.value)}
                    >
                      <item.icon className="mr-2 h-4 w-4" />
                      {item.label}
                    </Button>
                  ))}
                </nav>
                <div className="pt-4 border-t">
                  {sidebarBottomItems.map((item) => (
                    <Button
                      key={item.value}
                      variant={activeSection === item.value ? "secondary" : "ghost"}
                      className="w-full justify-start"
                      onClick={() => handleSectionClick(item.value)}
                    >
                      <item.icon className="mr-2 h-4 w-4" />
                      {item.label}
                    </Button>
                  ))}
                </div>
                <div className="pt-4 border-t">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="w-full justify-between">
                        <div className="flex items-center">
                          {theme === "light" && <Sun className="h-4 w-4 mr-2" />}
                          {theme === "dark" && <Moon className="h-4 w-4 mr-2" />}
                          {theme === "system" && <Monitor className="h-4 w-4 mr-2" />}
                          <span>Theme</span>
                        </div>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => setTheme("light")}>
                        <Sun className="h-4 w-4 mr-2" />
                        Light
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setTheme("dark")}>
                        <Moon className="h-4 w-4 mr-2" />
                        Dark
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setTheme("system")}>
                        <Monitor className="h-4 w-4 mr-2" />
                        System
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </ScrollArea>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Collapsed sidebar */}
      {!isMobile && sidebarCollapsed && (
        <div className="w-16 border-r bg-muted/10 flex flex-col items-center py-4">
          <div className="mb-4 flex justify-center">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSidebarCollapsed(false)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <TooltipProvider>
            <div className="space-y-4">
              {sidebarItems.map((item) => (
                <Tooltip key={item.value} delayDuration={300}>
                  <TooltipTrigger asChild>
                    <Button
                      variant={activeSection === item.value ? "secondary" : "ghost"}
                      size="icon"
                      className="h-10 w-10"
                      onClick={() => setActiveSection(item.value)}
                    >
                      <item.icon className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="right">{item.label}</TooltipContent>
                </Tooltip>
              ))}
              <div className="pt-4 border-t w-full"></div>
              {sidebarBottomItems.map((item) => (
                <Tooltip key={item.value} delayDuration={300}>
                  <TooltipTrigger asChild>
                    <Button
                      variant={activeSection === item.value ? "secondary" : "ghost"}
                      size="icon"
                      className="h-10 w-10"
                      onClick={() => setActiveSection(item.value)}
                    >
                      <item.icon className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="right">{item.label}</TooltipContent>
                </Tooltip>
              ))}
            </div>
          </TooltipProvider>
        </div>
      )}

      {/* Mobile overlay */}
      {isMobile && mobileMenuOpen && (
        <div className="fixed inset-0 bg-black/50 z-30" onClick={() => setMobileMenuOpen(false)} />
      )}

      {/* Main Content */}
      <div
        className={cn(
          "flex-1 flex transition-all duration-200 ease-in-out",
          isMobile ? "ml-0" : sidebarCollapsed ? "ml-16" : "ml-64",
        )}
      >
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <header className="h-14 border-b px-4 flex items-center justify-between">
            <h1 className="text-sm font-medium">
              {activeConversation ? activeConversation.title : "New conversation"}
            </h1>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={saveConversation}>
                Save conversation
              </Button>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={closeConversation}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </header>
          <motion.div
            className="flex-1 flex flex-col"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {children}
          </motion.div>
        </div>

        {/* Right Panel */}
        {!isMobile && (
          <motion.div
            className="w-80 border-l"
            initial={{ x: 80, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <div className="h-14 border-b px-4 flex items-center">
              <h2 className="font-medium">Conversation details</h2>
            </div>
            <div className="p-4">
              <div className="flex gap-4 border-b pb-4">
                <Button
                  variant={activePanel === "actions" ? "secondary" : "ghost"}
                  size="sm"
                  className="rounded-full"
                  onClick={() => setActivePanel("actions")}
                >
                  Actions
                </Button>
                <Button
                  variant={activePanel === "customer" ? "secondary" : "ghost"}
                  size="sm"
                  className="rounded-full"
                  onClick={() => setActivePanel("customer")}
                >
                  Customer
                </Button>
                <Button
                  variant={activePanel === "settings" ? "secondary" : "ghost"}
                  size="sm"
                  className="rounded-full"
                  onClick={() => setActivePanel("settings")}
                >
                  Settings
                </Button>
              </div>

              <AnimatePresence mode="wait">
                {activePanel === "actions" && <ActionPanel key="actions" />}

                {activePanel === "customer" && <CustomerPanel key="customer" />}

                {activePanel === "settings" && <SettingsPanel key="settings" />}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}

function ActionPanel() {
  return (
    <motion.div
      className="pt-4 space-y-4"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.2 }}
    >
      <h3 className="text-sm font-medium mb-2">Quick Actions</h3>
      <div className="grid grid-cols-2 gap-2">
        <Button variant="outline" size="sm" className="justify-start">
          <Eye className="h-4 w-4 mr-2" />
          Summarize
        </Button>
        <Button variant="outline" size="sm" className="justify-start">
          <Users className="h-4 w-4 mr-2" />
          Transfer
        </Button>
        <Button variant="outline" size="sm" className="justify-start">
          <LayoutGrid className="h-4 w-4 mr-2" />
          Escalate
        </Button>
        <Button variant="outline" size="sm" className="justify-start">
          <Functions className="h-4 w-4 mr-2" />
          Analyze
        </Button>
      </div>

      <div className="pt-4 border-t">
        <h3 className="text-sm font-medium mb-2">Suggested Responses</h3>
        <div className="space-y-2">
          <Button variant="outline" size="sm" className="w-full justify-start text-left h-auto py-2">
            I understand your concern. Let me check your account details.
          </Button>
          <Button variant="outline" size="sm" className="w-full justify-start text-left h-auto py-2">
            Would you like me to explain our refund policy?
          </Button>
          <Button variant="outline" size="sm" className="w-full justify-start text-left h-auto py-2">
            I'll need to verify your identity before proceeding.
          </Button>
        </div>
      </div>
    </motion.div>
  )
}

function CustomerPanel() {
  const { customer } = useAppContext()

  if (!customer)
    return (
      <motion.div
        className="pt-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.2 }}
      >
        <p className="text-sm text-muted-foreground">No customer information available</p>
      </motion.div>
    )

  return (
    <motion.div
      className="pt-4"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center text-primary font-medium">
          {customer.name
            .split(" ")
            .map((n) => n[0])
            .join("")}
        </div>
        <div>
          <h3 className="font-medium">{customer.name}</h3>
          <p className="text-sm text-muted-foreground">{customer.email}</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <h4 className="text-sm font-medium">Account Details</h4>
          <div className="grid grid-cols-2 gap-y-2 text-sm">
            <span className="text-muted-foreground">Account:</span>
            <span>{customer.accountNumber}</span>
            <span className="text-muted-foreground">Status:</span>
            <span>
              <span
                className={cn(
                  "px-2 py-0.5 rounded-full text-xs",
                  customer.status === "active"
                    ? "bg-green-100 text-green-800"
                    : customer.status === "inactive"
                      ? "bg-red-100 text-red-800"
                      : "bg-yellow-100 text-yellow-800",
                )}
              >
                {customer.status.charAt(0).toUpperCase() + customer.status.slice(1)}
              </span>
            </span>
            <span className="text-muted-foreground">Phone:</span>
            <span>{customer.phone}</span>
          </div>
        </div>

        <div className="pt-2 border-t">
          <h4 className="text-sm font-medium mb-2">Notes</h4>
          <p className="text-sm">{customer.notes}</p>
        </div>

        <div className="pt-2 border-t">
          <h4 className="text-sm font-medium mb-2">Recent Activity</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>Support ticket #4532</span>
              <span className="text-muted-foreground">2 days ago</span>
            </div>
            <div className="flex justify-between">
              <span>Billing update</span>
              <span className="text-muted-foreground">1 week ago</span>
            </div>
            <div className="flex justify-between">
              <span>Account created</span>
              <span className="text-muted-foreground">3 years ago</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

function SettingsPanel() {
  return (
    <motion.div
      className="pt-4 space-y-4"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.2 }}
    >
      <h3 className="text-sm font-medium mb-2">Conversation Settings</h3>

      <div className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">AI Model</label>
          <select className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
            <option>GPT-4o</option>
            <option>GPT-4o-mini</option>
            <option>Claude 3 Opus</option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Temperature</label>
          <input type="range" min="0" max="100" defaultValue="70" className="w-full" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Precise</span>
            <span>Balanced</span>
            <span>Creative</span>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Max Response Length</label>
          <select className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
            <option>Short (1000 tokens)</option>
            <option>Medium (2000 tokens)</option>
            <option>Long (4000 tokens)</option>
          </select>
        </div>

        <div className="flex items-center justify-between">
          <label className="text-sm font-medium">Voice Feedback</label>
          <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-muted transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background">
            <span className="inline-block h-5 w-5 translate-x-1 rounded-full bg-background transition-transform" />
          </div>
        </div>

        <div className="flex items-center justify-between">
          <label className="text-sm font-medium">Auto-Save</label>
          <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-primary transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background">
            <span className="inline-block h-5 w-5 translate-x-5 rounded-full bg-background transition-transform" />
          </div>
        </div>
      </div>
    </motion.div>
  )
}

