import { NextResponse } from "next/server"

// Define allowed log levels
const ALLOWED_LOG_LEVELS = ["debug", "info", "warn", "error"]

// Define rate limiting
const RATE_LIMIT = 50 // max logs per minute
const rateLimitMap = new Map<string, { count: number; timestamp: number }>()

// Clean up rate limit map every 10 minutes
setInterval(
  () => {
    const now = Date.now()
    for (const [key, value] of rateLimitMap.entries()) {
      if (now - value.timestamp > 10 * 60 * 1000) {
        rateLimitMap.delete(key)
      }
    }
  },
  10 * 60 * 1000,
)

export async function POST(request: Request) {
  try {
    // Get client IP for rate limiting
    const ip = request.headers.get("x-forwarded-for") || "unknown"

    // Check rate limit
    const now = Date.now()
    const rateLimit = rateLimitMap.get(ip) || { count: 0, timestamp: now }

    // Reset counter if more than a minute has passed
    if (now - rateLimit.timestamp > 60 * 1000) {
      rateLimit.count = 0
      rateLimit.timestamp = now
    }

    // Increment counter
    rateLimit.count++
    rateLimitMap.set(ip, rateLimit)

    // Check if rate limit exceeded
    if (rateLimit.count > RATE_LIMIT) {
      return NextResponse.json({ success: false, error: "Rate limit exceeded" }, { status: 429 })
    }

    // Parse log entry
    const logEntry = await request.json()

    // Validate log entry
    if (!logEntry || typeof logEntry !== "object") {
      return NextResponse.json({ success: false, error: "Invalid log entry" }, { status: 400 })
    }

    // Validate log level
    if (!logEntry.level || !ALLOWED_LOG_LEVELS.includes(logEntry.level)) {
      return NextResponse.json({ success: false, error: "Invalid log level" }, { status: 400 })
    }

    // Sanitize log entry to prevent injection attacks
    const sanitizedMessage =
      typeof logEntry.message === "string"
        ? logEntry.message.slice(0, 1000) // Limit message length
        : "No message"

    // In a real application, you would store logs in a database or send to a logging service
    console[logEntry.level](
      `[SERVER LOG] [${logEntry.level}]${logEntry.errorCode ? ` [${logEntry.errorCode}]` : ""} ${sanitizedMessage}`,
      {
        timestamp: logEntry.timestamp,
        context: logEntry.context,
        sessionId: logEntry.sessionId,
        data: logEntry.data,
      },
    )

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error processing log entry:", error)
    return NextResponse.json({ success: false, error: "Failed to process log entry" }, { status: 500 })
  }
}

