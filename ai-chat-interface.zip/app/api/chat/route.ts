import { NextResponse } from "next/server"
import { OpenAI } from "openai"
import Anthropic from "@anthropic-ai/sdk"
import { GoogleGenerativeAI } from "@google-ai/generative-ai"
import { logger } from "@/lib/logger"

// Allow streaming responses up to 60 seconds
export const maxDuration = 60

// Rate limiting configuration
const RATE_LIMIT = 20 // requests per minute
const rateLimitMap = new Map<string, { count: number; timestamp: number }>()

// Clean up rate limit map every 10 minutes
setInterval(
  () => {
    const now = Date.now()
    for (const [key, value] of rateLimitMap.entries()) {
      if (now - value.timestamp > 10 * 60 * 1000) {
        rateLimitMap.delete(key)
      }
    }
  },
  10 * 60 * 1000,
)

export async function POST(req: Request) {
  try {
    // Get client IP for rate limiting
    const ip = req.headers.get("x-forwarded-for") || "unknown"

    // Check rate limit
    const now = Date.now()
    const rateLimit = rateLimitMap.get(ip) || { count: 0, timestamp: now }

    // Reset counter if more than a minute has passed
    if (now - rateLimit.timestamp > 60 * 1000) {
      rateLimit.count = 0
      rateLimit.timestamp = now
    }

    // Increment counter
    rateLimit.count++
    rateLimitMap.set(ip, rateLimit)

    // Check if rate limit exceeded
    if (rateLimit.count > RATE_LIMIT) {
      return NextResponse.json({ error: "Rate limit exceeded. Please try again later." }, { status: 429 })
    }

    const { messages, provider, model, apiKey, baseUrl, temperature = 0.7, maxTokens = 1000 } = await req.json()

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Messages array is required and must not be empty" }, { status: 400 })
    }

    if (!provider) {
      return NextResponse.json({ error: "Provider is required" }, { status: 400 })
    }

    if (!apiKey && provider !== "litellm") {
      return NextResponse.json({ error: "API key is required" }, { status: 400 })
    }

    if (!model) {
      return NextResponse.json({ error: "Model is required" }, { status: 400 })
    }

    // Log the request (excluding the API key)
    logger.info("Chat API request", {
      provider,
      model,
      messagesCount: messages.length,
      temperature,
      maxTokens,
    })

    // Create a TransformStream to stream the response
    const encoder = new TextEncoder()
    const stream = new TransformStream()
    const writer = stream.writable.getWriter()

    // Function to write a chunk to the stream
    const writeChunk = async (chunk: string) => {
      await writer.write(encoder.encode(`data: ${JSON.stringify({ text: chunk })}\n\n`))
    }

    // Function to end the stream
    const endStream = async () => {
      await writer.write(encoder.encode("data: [DONE]\n\n"))
      await writer.close()
    }

    // Process the request based on the provider
    try {
      switch (provider) {
        case "openai":
          await handleOpenAI(messages, model, apiKey, baseUrl, temperature, maxTokens, writeChunk, endStream)
          break
        case "anthropic":
          await handleAnthropic(messages, model, apiKey, baseUrl, temperature, maxTokens, writeChunk, endStream)
          break
        case "google":
          await handleGoogle(messages, model, apiKey, temperature, maxTokens, writeChunk, endStream)
          break
        case "openrouter":
          await handleOpenRouter(messages, model, apiKey, temperature, maxTokens, writeChunk, endStream)
          break
        case "huggingface":
          await handleHuggingFace(messages, model, apiKey, baseUrl, temperature, writeChunk, endStream)
          break
        case "litellm":
          await handleLiteLLM(messages, model, apiKey, baseUrl, temperature, maxTokens, writeChunk, endStream)
          break
        default:
          throw new Error(`Unsupported provider: ${provider}`)
      }
    } catch (error: any) {
      logger.error("Error in chat API", {
        provider,
        model,
        error: error.message,
        errorCode: "PROVIDER_ERROR",
      })

      // Try to write an error message to the stream
      try {
        await writeChunk(`Error: ${error.message}`)
        await endStream()
      } catch (streamError) {
        // If we can't write to the stream, it's probably already closed
        logger.error("Error writing to stream", {
          error: streamError instanceof Error ? streamError.message : String(streamError),
          errorCode: "STREAM_ERROR",
        })
      }
    }

    return new Response(stream.readable, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    })
  } catch (error: any) {
    logger.error("Unexpected error in chat API", {
      error: error.message || "Unknown error",
      errorCode: "UNEXPECTED_ERROR",
    })
    return NextResponse.json({ error: error.message || "An unexpected error occurred" }, { status: 500 })
  }
}

async function handleOpenAI(
  messages: any[],
  model: string,
  apiKey: string,
  baseUrl: string | undefined,
  temperature: number,
  maxTokens: number,
  writeChunk: (chunk: string) => Promise<void>,
  endStream: () => Promise<void>,
) {
  try {
    const openai = new OpenAI({
      apiKey,
      baseURL: baseUrl,
    })

    const stream = await openai.chat.completions.create({
      model,
      messages,
      temperature,
      max_tokens: maxTokens,
      stream: true,
    })

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || ""
      if (content) {
        await writeChunk(content)
      }
    }

    await endStream()
  } catch (error) {
    logger.error("OpenAI API error", {
      error: error instanceof Error ? error.message : String(error),
      model,
      errorCode: "OPENAI_ERROR",
    })
    throw error
  }
}

async function handleAnthropic(
  messages: any[],
  model: string,
  apiKey: string,
  baseUrl: string | undefined,
  temperature: number,
  maxTokens: number,
  writeChunk: (chunk: string) => Promise<void>,
  endStream: () => Promise<void>,
) {
  try {
    const anthropic = new Anthropic({
      apiKey,
      baseURL: baseUrl,
    })

    // Convert messages to Anthropic format
    const systemMessage = messages.find((m) => m.role === "system")?.content || ""
    const conversationMessages = messages.filter((m) => m.role !== "system")

    const stream = await anthropic.messages.create({
      model,
      messages: conversationMessages.map((m) => ({
        role: m.role === "assistant" ? "assistant" : "user",
        content: m.content,
      })),
      system: systemMessage,
      temperature,
      max_tokens: maxTokens,
      stream: true,
    })

    for await (const chunk of stream) {
      if (chunk.type === "content_block_delta" && chunk.delta.text) {
        await writeChunk(chunk.delta.text)
      }
    }

    await endStream()
  } catch (error) {
    logger.error("Anthropic API error", {
      error: error instanceof Error ? error.message : String(error),
      model,
      errorCode: "ANTHROPIC_ERROR",
    })
    throw error
  }
}

async function handleGoogle(
  messages: any[],
  model: string,
  apiKey: string,
  temperature: number,
  maxTokens: number,
  writeChunk: (chunk: string) => Promise<void>,
  endStream: () => Promise<void>,
) {
  try {
    const genAI = new GoogleGenerativeAI(apiKey)
    const geminiModel = genAI.getGenerativeModel({ model })

    // Convert messages to Google format
    const systemMessage = messages.find((m) => m.role === "system")?.content || ""
    const conversationMessages = messages.filter((m) => m.role !== "system")

    const chat = geminiModel.startChat({
      history: conversationMessages.map((m) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }],
      })),
      systemInstruction: systemMessage ? { text: systemMessage } : undefined,
    })

    const lastUserMessage = conversationMessages[conversationMessages.length - 1]

    const result = await chat.sendMessageStream(lastUserMessage.content)

    for await (const chunk of result.stream) {
      const text = chunk.text()
      if (text) {
        await writeChunk(text)
      }
    }

    await endStream()
  } catch (error) {
    logger.error("Google API error", {
      error: error instanceof Error ? error.message : String(error),
      model,
      errorCode: "GOOGLE_ERROR",
    })
    throw error
  }
}

async function handleOpenRouter(
  messages: any[],
  model: string,
  apiKey: string,
  temperature: number,
  maxTokens: number,
  writeChunk: (chunk: string) => Promise<void>,
  endStream: () => Promise<void>,
) {
  try {
    const openai = new OpenAI({
      apiKey,
      baseURL: "https://openrouter.ai/api/v1",
    })

    const stream = await openai.chat.completions.create({
      model,
      messages,
      temperature,
      max_tokens: maxTokens,
      stream: true,
    })

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || ""
      if (content) {
        await writeChunk(content)
      }
    }

    await endStream()
  } catch (error) {
    logger.error("OpenRouter API error", {
      error: error instanceof Error ? error.message : String(error),
      model,
      errorCode: "OPENROUTER_ERROR",
    })
    throw error
  }
}

async function handleHuggingFace(
  messages: any[],
  model: string,
  apiKey: string,
  baseUrl: string | undefined,
  temperature: number,
  writeChunk: (chunk: string) => Promise<void>,
  endStream: () => Promise<void>,
) {
  try {
    // Hugging Face doesn't support streaming directly, so we'll simulate it

    // Format the messages as a prompt
    let prompt = ""
    for (const message of messages) {
      if (message.role === "system") {
        prompt += `System: ${message.content}\n\n`
      } else if (message.role === "user") {
        prompt += `User: ${message.content}\n\n`
      } else if (message.role === "assistant") {
        prompt += `Assistant: ${message.content}\n\n`
      }
    }
    prompt += "Assistant: "

    const url = baseUrl ? `${baseUrl}/${model}` : `https://api-inference.huggingface.co/models/${model}`

    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          temperature,
          return_full_text: false,
        },
      }),
    })

    if (!response.ok) {
      const error = await response.text()
      throw new Error(`Hugging Face API error: ${error}`)
    }

    const result = await response.json()
    const text = result[0]?.generated_text || ""

    // Simulate streaming by sending chunks of 5 characters
    const chunkSize = 5
    for (let i = 0; i < text.length; i += chunkSize) {
      const chunk = text.substring(i, i + chunkSize)
      await writeChunk(chunk)
      // Add a small delay to simulate streaming
      await new Promise((resolve) => setTimeout(resolve, 10))
    }

    await endStream()
  } catch (error) {
    logger.error("Hugging Face API error", {
      error: error instanceof Error ? error.message : String(error),
      model,
      errorCode: "HUGGINGFACE_ERROR",
    })
    throw error
  }
}

async function handleLiteLLM(
  messages: any[],
  model: string,
  apiKey: string | undefined,
  baseUrl: string | undefined,
  temperature: number,
  maxTokens: number,
  writeChunk: (chunk: string) => Promise<void>,
  endStream: () => Promise<void>,
) {
  try {
    const url = baseUrl || "http://localhost:8000/v1"

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    }

    if (apiKey) {
      headers["Authorization"] = `Bearer ${apiKey}`
    }

    const response = await fetch(`${url}/chat/completions`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model,
        messages,
        temperature,
        max_tokens: maxTokens,
        stream: true,
      }),
    })

    if (!response.ok) {
      const error = await response.text()
      throw new Error(`LiteLLM API error: ${error}`)
    }

    const reader = response.body?.getReader()
    if (!reader) {
      throw new Error("Response body is not readable")
    }

    const decoder = new TextDecoder()
    let buffer = ""

    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      buffer += decoder.decode(value, { stream: true })

      // Process complete lines
      const lines = buffer.split("\n")
      buffer = lines.pop() || ""

      for (const line of lines) {
        if (line.startsWith("data: ") && line !== "data: [DONE]") {
          try {
            const data = JSON.parse(line.substring(6))
            const content = data.choices?.[0]?.delta?.content || ""
            if (content) {
              await writeChunk(content)
            }
          } catch (e) {
            // Ignore parsing errors
          }
        }
      }
    }

    await endStream()
  } catch (error) {
    logger.error("LiteLLM API error", {
      error: error instanceof Error ? error.message : String(error),
      model,
      errorCode: "LITELLM_ERROR",
    })
    throw error
  }
}

