"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { toast } from "@/components/ui/use-toast"

type Section = "tasks" | "functions" | "integrations" | "users" | "settings" | "preview" | "performance"
type Panel = "actions" | "customer" | "settings"
type Theme = "light" | "dark" | "system"

interface Conversation {
  id: string
  title: string
  lastMessage: string
  timestamp: Date
}

interface Customer {
  id: string
  name: string
  accountNumber: string
  status: "active" | "inactive" | "pending"
  email: string
  phone: string
  notes: string
}

interface AppContextType {
  activeSection: Section
  setActiveSection: (section: Section) => void
  activePanel: Panel
  setActivePanel: (panel: Panel) => void
  theme: Theme
  setTheme: (theme: Theme) => void
  sidebarCollapsed: boolean
  setSidebarCollapsed: (collapsed: boolean) => void
  conversations: Conversation[]
  activeConversation: Conversation | null
  setActiveConversation: (conversation: Conversation | null) => void
  customer: Customer | null
  setCustomer: (customer: Customer | null) => void
  saveConversation: () => void
  closeConversation: () => void
  isRecording: boolean
  setIsRecording: (recording: boolean) => void
}

const defaultCustomer: Customer = {
  id: "cust-1234",
  name: "John Doe",
  accountNumber: "#12345",
  status: "active",
  email: "john.doe@example.com",
  phone: "+1 (555) 123-4567",
  notes: "Premium customer since 2020. Prefers email communication.",
}

const defaultConversations: Conversation[] = [
  {
    id: "conv-1",
    title: "Billing inquiry",
    lastMessage: "Your current bill is $150, due on August 31, 2024.",
    timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
  },
  {
    id: "conv-2",
    title: "Technical support",
    lastMessage: "Have you tried restarting your device?",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
  },
  {
    id: "conv-3",
    title: "Account upgrade",
    lastMessage: "The premium plan costs $19.99 per month.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
  },
]

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [activeSection, setActiveSection] = useState<Section>("tasks")
  const [activePanel, setActivePanel] = useState<Panel>("actions")
  const [theme, setTheme] = useState<Theme>("system")
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [conversations, setConversations] = useState<Conversation[]>(defaultConversations)
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(defaultConversations[0])
  const [customer, setCustomer] = useState<Customer | null>(defaultCustomer)
  const [isRecording, setIsRecording] = useState(false)

  // Apply theme changes
  useEffect(() => {
    const root = window.document.documentElement
    root.classList.remove("light", "dark")

    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
      root.classList.add(systemTheme)
    } else {
      root.classList.add(theme)
    }
  }, [theme])

  const saveConversation = () => {
    if (activeConversation) {
      // In a real app, you would save to a database
      toast({
        title: "Conversation saved",
        description: `"${activeConversation.title}" has been saved successfully.`,
      })
    }
  }

  const closeConversation = () => {
    setActiveConversation(null)
    toast({
      title: "Conversation closed",
      description: "The conversation has been closed.",
    })
  }

  return (
    <AppContext.Provider
      value={{
        activeSection,
        setActiveSection,
        activePanel,
        setActivePanel,
        theme,
        setTheme,
        sidebarCollapsed,
        setSidebarCollapsed,
        conversations,
        activeConversation,
        setActiveConversation,
        customer,
        setCustomer,
        saveConversation,
        closeConversation,
        isRecording,
        setIsRecording,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useAppContext() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error("useAppContext must be used within an AppProvider")
  }
  return context
}

