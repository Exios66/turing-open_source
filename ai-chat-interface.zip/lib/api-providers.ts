"use client"

import React from "react"

import { logger } from "./logger"

export type ApiProvider = "openai" | "anthropic" | "google" | "openrouter" | "huggingface" | "litellm"

export interface ApiConfig {
  provider: ApiProvider
  apiKey: string
  baseUrl?: string
  models?: string[]
  defaultModel?: string
  organizationId?: string
  additionalHeaders?: Record<string, string>
}

export interface ApiProviderInfo {
  id: ApiProvider
  name: string
  description: string
  url: string
  logoUrl: string
  defaultBaseUrl: string
  defaultModels: string[]
  supportsStreaming: boolean
  requiresApiKey: boolean
  apiKeyName: string
  apiKeyLink: string
}

export const API_PROVIDERS: Record<ApiProvider, ApiProviderInfo> = {
  openai: {
    id: "openai",
    name: "OpenAI",
    description: "Access GPT models like GPT-4o and GPT-3.5 Turbo",
    url: "https://openai.com",
    logoUrl: "/logos/openai.svg",
    defaultBaseUrl: "https://api.openai.com/v1",
    defaultModels: ["gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo"],
    supportsStreaming: true,
    requiresApiKey: true,
    apiKeyName: "OpenAI API Key",
    apiKeyLink: "https://platform.openai.com/api-keys",
  },
  anthropic: {
    id: "anthropic",
    name: "Anthropic",
    description: "Access Claude models like Claude 3 Opus and Sonnet",
    url: "https://anthropic.com",
    logoUrl: "/logos/anthropic.svg",
    defaultBaseUrl: "https://api.anthropic.com",
    defaultModels: ["claude-3-opus-20240229", "claude-3-sonnet-20240229", "claude-3-haiku-20240307"],
    supportsStreaming: true,
    requiresApiKey: true,
    apiKeyName: "Anthropic API Key",
    apiKeyLink: "https://console.anthropic.com/settings/keys",
  },
  google: {
    id: "google",
    name: "Google AI",
    description: "Access Gemini models from Google",
    url: "https://ai.google.dev",
    logoUrl: "/logos/google.svg",
    defaultBaseUrl: "https://generativelanguage.googleapis.com",
    defaultModels: ["gemini-1.5-pro", "gemini-1.5-flash"],
    supportsStreaming: true,
    requiresApiKey: true,
    apiKeyName: "Google AI API Key",
    apiKeyLink: "https://ai.google.dev/tutorials/setup",
  },
  openrouter: {
    id: "openrouter",
    name: "OpenRouter",
    description: "Access multiple AI models through a single API",
    url: "https://openrouter.ai",
    logoUrl: "/logos/openrouter.svg",
    defaultBaseUrl: "https://openrouter.ai/api/v1",
    defaultModels: ["openai/gpt-4o", "anthropic/claude-3-opus", "google/gemini-1.5-pro"],
    supportsStreaming: true,
    requiresApiKey: true,
    apiKeyName: "OpenRouter API Key",
    apiKeyLink: "https://openrouter.ai/keys",
  },
  huggingface: {
    id: "huggingface",
    name: "Hugging Face",
    description: "Access open-source models hosted on Hugging Face",
    url: "https://huggingface.co",
    logoUrl: "/logos/huggingface.svg",
    defaultBaseUrl: "https://api-inference.huggingface.co/models",
    defaultModels: ["mistralai/Mistral-7B-Instruct-v0.2", "meta-llama/Llama-2-70b-chat-hf"],
    supportsStreaming: false,
    requiresApiKey: true,
    apiKeyName: "Hugging Face API Key",
    apiKeyLink: "https://huggingface.co/settings/tokens",
  },
  litellm: {
    id: "litellm",
    name: "LiteLLM",
    description: "Proxy to multiple LLM providers with a unified API",
    url: "https://litellm.ai",
    logoUrl: "/logos/litellm.svg",
    defaultBaseUrl: "http://localhost:8000",
    defaultModels: ["gpt-4o", "claude-3-opus", "gemini-1.5-pro"],
    supportsStreaming: true,
    requiresApiKey: false,
    apiKeyName: "LiteLLM API Key",
    apiKeyLink: "https://docs.litellm.ai/docs/proxy/virtual_keys",
  },
}

export class ApiProviderService {
  private static instance: ApiProviderService
  private configs: Record<ApiProvider, ApiConfig | null> = {
    openai: null,
    anthropic: null,
    google: null,
    openrouter: null,
    huggingface: null,
    litellm: null,
  }
  private activeProvider: ApiProvider = "openai"
  private listeners: Set<(provider: ApiProvider, config: ApiConfig | null) => void> = new Set()

  private constructor() {
    this.loadFromStorage()
  }

  public static getInstance(): ApiProviderService {
    if (!ApiProviderService.instance) {
      ApiProviderService.instance = new ApiProviderService()
    }
    return ApiProviderService.instance
  }

  private loadFromStorage(): void {
    try {
      const storedConfigs = localStorage.getItem("api_configs")
      const activeProvider = localStorage.getItem("active_api_provider")

      if (storedConfigs) {
        this.configs = JSON.parse(storedConfigs)
      }

      if (activeProvider && this.configs[activeProvider as ApiProvider]) {
        this.activeProvider = activeProvider as ApiProvider
      }

      logger.info("API provider configs loaded from storage", {
        activeProvider: this.activeProvider,
        configuredProviders: Object.keys(this.configs).filter((key) => this.configs[key as ApiProvider] !== null),
      })
    } catch (error) {
      logger.error("Error loading API provider configs from storage", error)
    }
  }

  private saveToStorage(): void {
    try {
      localStorage.setItem("api_configs", JSON.stringify(this.configs))
      localStorage.setItem("active_api_provider", this.activeProvider)
    } catch (error) {
      logger.error("Error saving API provider configs to storage", error)
    }
  }

  private notifyListeners(): void {
    const config = this.configs[this.activeProvider]
    this.listeners.forEach((listener) => listener(this.activeProvider, config))
  }

  public subscribe(listener: (provider: ApiProvider, config: ApiConfig | null) => void): () => void {
    this.listeners.add(listener)
    // Immediately notify with current state
    listener(this.activeProvider, this.configs[this.activeProvider])

    // Return unsubscribe function
    return () => {
      this.listeners.delete(listener)
    }
  }

  public setConfig(provider: ApiProvider, config: ApiConfig | null): void {
    this.configs[provider] = config
    this.saveToStorage()

    if (provider === this.activeProvider || (config && !this.configs[this.activeProvider])) {
      this.activeProvider = provider
      this.notifyListeners()
    }

    logger.info("API provider config updated", { provider })
  }

  public setActiveProvider(provider: ApiProvider): void {
    if (this.configs[provider]) {
      this.activeProvider = provider
      this.saveToStorage()
      this.notifyListeners()
      logger.info("Active API provider changed", { provider })
    } else {
      logger.warn("Cannot set active provider - no config exists", { provider })
    }
  }

  public getConfig(provider: ApiProvider): ApiConfig | null {
    return this.configs[provider]
  }

  public getActiveProvider(): ApiProvider {
    return this.activeProvider
  }

  public getActiveConfig(): ApiConfig | null {
    return this.configs[this.activeProvider]
  }

  public getAllConfigs(): Record<ApiProvider, ApiConfig | null> {
    return { ...this.configs }
  }

  public hasAnyConfig(): boolean {
    return Object.values(this.configs).some((config) => config !== null)
  }
}

export const apiProviderService = ApiProviderService.getInstance()

// React hook for API providers
export function useApiProviders() {
  const [state, setState] = React.useState<{
    activeProvider: ApiProvider
    activeConfig: ApiConfig | null
    configs: Record<ApiProvider, ApiConfig | null>
  }>({
    activeProvider: apiProviderService.getActiveProvider(),
    activeConfig: apiProviderService.getActiveConfig(),
    configs: apiProviderService.getAllConfigs(),
  })

  React.useEffect(() => {
    return apiProviderService.subscribe((provider, config) => {
      setState({
        activeProvider: provider,
        activeConfig: config,
        configs: apiProviderService.getAllConfigs(),
      })
    })
  }, [])

  return {
    providers: API_PROVIDERS,
    activeProvider: state.activeProvider,
    activeConfig: state.activeConfig,
    configs: state.configs,
    setConfig: apiProviderService.setConfig.bind(apiProviderService),
    setActiveProvider: apiProviderService.setActiveProvider.bind(apiProviderService),
    hasAnyConfig: apiProviderService.hasAnyConfig(),
  }
}

