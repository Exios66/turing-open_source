"use client"

import React from "react"

import { logger } from "./logger"

export type User = {
  id: string
  name: string
  email: string
  role: string
  avatar?: string
}

export type AuthState = {
  isAuthenticated: boolean
  user: User | null
  token: string | null
  loading: boolean
  error: string | null
}

export type LoginCredentials = {
  email: string
  password: string
}

export type RegisterData = {
  name: string
  email: string
  password: string
}

class AuthService {
  private static instance: AuthService
  private authState: AuthState = {
    isAuthenticated: false,
    user: null,
    token: null,
    loading: true,
    error: null,
  }
  private listeners: Set<(state: AuthState) => void> = new Set()
  private tokenKey = "auth_token"
  private userKey = "auth_user"

  private constructor() {
    // Initialize auth state from storage
    this.loadFromStorage()
  }

  public static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService()
    }
    return AuthService.instance
  }

  private loadFromStorage(): void {
    try {
      const token = localStorage.getItem(this.tokenKey)
      const userJson = localStorage.getItem(this.userKey)

      if (token && userJson) {
        const user = JSON.parse(userJson)
        this.authState = {
          isAuthenticated: true,
          user,
          token,
          loading: false,
          error: null,
        }
        logger.info("User authenticated from storage", { userId: user.id })
      } else {
        this.authState = {
          isAuthenticated: false,
          user: null,
          token: null,
          loading: false,
          error: null,
        }
      }
    } catch (error) {
      logger.error("Error loading auth state from storage", error)
      this.authState = {
        isAuthenticated: false,
        user: null,
        token: null,
        loading: false,
        error: "Failed to load authentication state",
      }
    }
  }

  private saveToStorage(token: string, user: User): void {
    try {
      localStorage.setItem(this.tokenKey, token)
      localStorage.setItem(this.userKey, JSON.stringify(user))
    } catch (error) {
      logger.error("Error saving auth state to storage", error)
    }
  }

  private clearStorage(): void {
    try {
      localStorage.removeItem(this.tokenKey)
      localStorage.removeItem(this.userKey)
    } catch (error) {
      logger.error("Error clearing auth state from storage", error)
    }
  }

  private updateState(newState: Partial<AuthState>): void {
    this.authState = { ...this.authState, ...newState }
    this.notifyListeners()
  }

  private notifyListeners(): void {
    this.listeners.forEach((listener) => listener(this.authState))
  }

  public subscribe(listener: (state: AuthState) => void): () => void {
    this.listeners.add(listener)
    // Immediately notify with current state
    listener(this.authState)

    // Return unsubscribe function
    return () => {
      this.listeners.delete(listener)
    }
  }

  public async login(credentials: LoginCredentials): Promise<User> {
    try {
      this.updateState({ loading: true, error: null })

      // In a real app, this would be an API call
      // For demo purposes, we'll simulate a successful login
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Simulate successful login
      const user: User = {
        id: "1",
        name: "Demo User",
        email: credentials.email,
        role: "user",
        avatar: "https://ui-avatars.com/api/?name=Demo+User",
      }

      const token = "demo_token_" + Math.random().toString(36).substring(2)

      this.saveToStorage(token, user)
      this.updateState({
        isAuthenticated: true,
        user,
        token,
        loading: false,
      })

      logger.info("User logged in", { userId: user.id })
      return user
    } catch (error: any) {
      logger.error("Login failed", error)
      this.updateState({
        isAuthenticated: false,
        user: null,
        token: null,
        loading: false,
        error: error.message || "Login failed",
      })
      throw error
    }
  }

  public async register(data: RegisterData): Promise<User> {
    try {
      this.updateState({ loading: true, error: null })

      // In a real app, this would be an API call
      // For demo purposes, we'll simulate a successful registration
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Simulate successful registration
      const user: User = {
        id: "1",
        name: data.name,
        email: data.email,
        role: "user",
        avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(data.name)}`,
      }

      const token = "demo_token_" + Math.random().toString(36).substring(2)

      this.saveToStorage(token, user)
      this.updateState({
        isAuthenticated: true,
        user,
        token,
        loading: false,
      })

      logger.info("User registered", { userId: user.id })
      return user
    } catch (error: any) {
      logger.error("Registration failed", error)
      this.updateState({
        isAuthenticated: false,
        user: null,
        token: null,
        loading: false,
        error: error.message || "Registration failed",
      })
      throw error
    }
  }

  public async logout(): Promise<void> {
    try {
      this.updateState({ loading: true })

      // In a real app, this might involve an API call
      await new Promise((resolve) => setTimeout(resolve, 500))

      this.clearStorage()
      this.updateState({
        isAuthenticated: false,
        user: null,
        token: null,
        loading: false,
        error: null,
      })

      logger.info("User logged out")
    } catch (error: any) {
      logger.error("Logout failed", error)
      this.updateState({
        loading: false,
        error: error.message || "Logout failed",
      })
      throw error
    }
  }

  public getAuthState(): AuthState {
    return this.authState
  }

  public getToken(): string | null {
    return this.authState.token
  }

  public isAuthenticated(): boolean {
    return this.authState.isAuthenticated
  }

  public getUser(): User | null {
    return this.authState.user
  }
}

export const authService = AuthService.getInstance()

// React hook for auth
export function useAuth() {
  const [authState, setAuthState] = React.useState<AuthState>(authService.getAuthState())

  React.useEffect(() => {
    return authService.subscribe(setAuthState)
  }, [])

  return {
    ...authState,
    login: authService.login.bind(authService),
    register: authService.register.bind(authService),
    logout: authService.logout.bind(authService),
  }
}

