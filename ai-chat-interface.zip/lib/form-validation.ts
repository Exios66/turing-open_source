export type ValidationRule = {
  test: (value: any) => boolean
  message: string
}

export type FieldValidation = {
  required?: boolean | string
  minLength?: [number, string?]
  maxLength?: [number, string?]
  pattern?: [RegExp, string?]
  email?: boolean | string
  url?: boolean | string
  min?: [number, string?]
  max?: [number, string?]
  custom?: ValidationRule[]
}

export type ValidationResult = {
  valid: boolean
  errors: Record<string, string[]>
}

export type FormValues = Record<string, any>

export type FormValidation = Record<string, FieldValidation>

export const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
export const urlRegex = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/

export function validateField(value: any, validation: FieldValidation): string[] {
  const errors: string[] = []

  // Handle undefined or null values for required check
  const isEmptyValue = value === undefined || value === null || value === ""

  // Required check
  if (validation.required) {
    const message = typeof validation.required === "string" ? validation.required : "This field is required"

    if (isEmptyValue) {
      errors.push(message)
      // If the field is required and empty, no need to check other validations
      return errors
    }
  } else if (isEmptyValue) {
    // If the field is not required and empty, skip other validations
    return errors
  }

  // String validations (only apply to string values)
  if (typeof value === "string") {
    // Min length
    if (validation.minLength && value.length < validation.minLength[0]) {
      errors.push(validation.minLength[1] || `Must be at least ${validation.minLength[0]} characters`)
    }

    // Max length
    if (validation.maxLength && value.length > validation.maxLength[0]) {
      errors.push(validation.maxLength[1] || `Must be at most ${validation.maxLength[0]} characters`)
    }

    // Pattern
    if (validation.pattern && !validation.pattern[0].test(value)) {
      errors.push(validation.pattern[1] || "Invalid format")
    }

    // Email
    if (validation.email && !emailRegex.test(value)) {
      errors.push(typeof validation.email === "string" ? validation.email : "Invalid email address")
    }

    // URL
    if (validation.url && !urlRegex.test(value)) {
      errors.push(typeof validation.url === "string" ? validation.url : "Invalid URL")
    }
  }

  // Number validations (only apply to number values or string that can be converted to numbers)
  const numValue = typeof value === "number" ? value : Number(value)
  if (!isNaN(numValue)) {
    // Min value
    if (validation.min && numValue < validation.min[0]) {
      errors.push(validation.min[1] || `Must be at least ${validation.min[0]}`)
    }

    // Max value
    if (validation.max && numValue > validation.max[0]) {
      errors.push(validation.max[1] || `Must be at most ${validation.max[0]}`)
    }
  }

  // Custom validations
  if (validation.custom) {
    validation.custom.forEach((rule) => {
      if (!rule.test(value)) {
        errors.push(rule.message)
      }
    })
  }

  return errors
}

export function validateForm(values: FormValues, validations: FormValidation): ValidationResult {
  const errors: Record<string, string[]> = {}
  let valid = true

  Object.keys(validations).forEach((field) => {
    const fieldErrors = validateField(values[field], validations[field])
    if (fieldErrors.length > 0) {
      errors[field] = fieldErrors
      valid = false
    }
  })

  return { valid, errors }
}

