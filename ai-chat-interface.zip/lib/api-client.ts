import { logger } from "./logger"

export type ApiRequestOptions = {
  method?: "GET" | "POST" | "PUT" | "DELETE" | "PATCH"
  headers?: Record<string, string>
  body?: any
  timeout?: number
  retries?: number
  retryDelay?: number
  cache?: RequestCache
  credentials?: RequestCredentials
  signal?: AbortSignal
  parseResponse?: boolean
}

export type ApiResponse<T> = {
  data: T | null
  error: Error | null
  status: number
  headers: Headers
  ok: boolean
}

export class ApiError extends Error {
  status: number
  data: any

  constructor(message: string, status: number, data?: any) {
    super(message)
    this.name = "ApiError"
    this.status = status
    this.data = data
  }
}

export async function apiRequest<T = any>(url: string, options: ApiRequestOptions = {}): Promise<ApiResponse<T>> {
  const {
    method = "GET",
    headers = {},
    body,
    timeout = 30000,
    retries = 3,
    retryDelay = 1000,
    cache = "default",
    credentials = "same-origin",
    signal,
    parseResponse = true,
  } = options

  // Create a controller for timeout if no signal is provided
  const controller = signal ? null : new AbortController()
  const timeoutId = controller ? setTimeout(() => controller.abort(), timeout) : null

  const requestSignal = signal || (controller ? controller.signal : undefined)

  const requestOptions: RequestInit = {
    method,
    headers: {
      "Content-Type": "application/json",
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
    cache,
    credentials,
    signal: requestSignal,
  }

  let attempts = 0
  let lastError: any = null

  while (attempts < retries + 1) {
    try {
      const startTime = Date.now()

      logger.debug(`API Request: ${method} ${url}`, {
        method,
        url,
        attempt: attempts + 1,
      })

      const response = await fetch(url, requestOptions)
      const endTime = Date.now()

      logger.debug(`API Response: ${method} ${url}`, {
        status: response.status,
        duration: endTime - startTime,
        attempt: attempts + 1,
      })

      let data = null

      if (parseResponse) {
        const contentType = response.headers.get("content-type")

        if (contentType && contentType.includes("application/json")) {
          data = await response.json()
        } else if (contentType && contentType.includes("text/")) {
          data = await response.text()
        } else {
          data = await response.blob()
        }
      }

      if (!response.ok) {
        const errorMessage = data?.message || `API request failed with status ${response.status}`
        logger.error(`API Error: ${method} ${url}`, {
          status: response.status,
          data,
          duration: endTime - startTime,
          errorCode: `HTTP_${response.status}`,
        })

        throw new ApiError(errorMessage, response.status, data)
      }

      // Clean up timeout
      if (timeoutId !== null) {
        clearTimeout(timeoutId)
      }

      return {
        data,
        error: null,
        status: response.status,
        headers: response.headers,
        ok: response.ok,
      }
    } catch (error: any) {
      lastError = error

      // Don't retry if it was a timeout or abort
      if (error.name === "AbortError") {
        logger.error(`API Request Aborted: ${method} ${url}`, {
          error: error.message,
          errorCode: "REQUEST_ABORTED",
        })
        break
      }

      // Don't retry if it's a client error (4xx)
      if (error instanceof ApiError && error.status >= 400 && error.status < 500) {
        break
      }

      attempts++

      if (attempts <= retries) {
        const delay = retryDelay * attempts
        logger.warn(`Retrying API request: ${method} ${url}`, {
          attempt: attempts,
          maxRetries: retries,
          delay,
          errorCode: "RETRY_REQUEST",
        })

        await new Promise((resolve) => setTimeout(resolve, delay))
      }
    }
  }

  // Clean up timeout
  if (timeoutId !== null) {
    clearTimeout(timeoutId)
  }

  // If we got here, all retries failed
  if (lastError) {
    throw lastError
  }

  // This should never happen, but TypeScript needs it
  return {
    data: null,
    error: new Error("Unknown error occurred"),
    status: 0,
    headers: new Headers(),
    ok: false,
  }
}

// Utility functions for common API operations
export const apiClient = {\
  get: <T>(url: string, options?: Omit<ApiRequestOptions, 'method' | 'body'>) => 
    apiRequest<T>(url, { ...options, method: 'GET' }),
    
  post: <T>(url: string, body: any, options?: Omit<ApiRequestOptions, 'method'>) => 
    apiRequest<T>(url, { ...options, method: 'POST', body }),
    
  put: <T>(url: string, body: any, options?: Omit<ApiRequestOptions, 'method'>) => 
    apiRequest<T>(url, { ...options, method: 'PUT', body }),
    
  patch: <T>(url: string, body: any, options?: Omit<ApiRequestOptions, 'method'>) => 
    apiRequest<T>(url, { ...options, method: 'PATCH', body }),
    
  delete: <T>(url: string, options?: Omit<ApiRequestOptions, 'method'>) => 
    apiRequest<T>(url, { ...options, method: 'DELETE' }),
}

