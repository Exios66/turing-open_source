type LogLevel = "debug" | "info" | "warn" | "error"

interface LogEntry {
  message: string
  level: LogLevel
  timestamp: string
  data?: any
  context?: string
  userId?: string
  sessionId?: string
  errorCode?: string
  stack?: string
}

class Logger {
  private static instance: Logger
  private logStorage: LogEntry[] = []
  private maxStoredLogs = 100
  private consoleEnabled = true
  private serverLogEndpoint = "/api/logs"
  private errorCodes: Record<string, string> = {
    AUTH_FAILED: "Authentication failed",
    API_ERROR: "API request failed",
    NETWORK_ERROR: "Network connection issue",
    VALIDATION_ERROR: "Input validation failed",
    UNKNOWN_ERROR: "Unknown error occurred",
  }

  private constructor() {
    // Private constructor to enforce singleton pattern
  }

  public static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger()
    }
    return Logger.instance
  }

  private createLogEntry(level: LogLevel, message: string, data?: any): LogEntry {
    const errorCode = this.getErrorCode(message, data, level)

    const entry: LogEntry = {
      message,
      level,
      timestamp: new Date().toISOString(),
      data,
      context: this.getContext(),
      sessionId: this.getSessionId(),
    }

    if (errorCode) {
      entry.errorCode = errorCode
    }

    if (data instanceof Error || (data && data.stack)) {
      entry.stack = data.stack
    }

    return entry
  }

  private getErrorCode(message: string, data?: any, level?: LogLevel): string | undefined {
    // Try to extract error code from data
    if (data && typeof data === "object") {
      if (data.code) return data.code
      if (data.errorCode) return data.errorCode
    }

    // Try to match message patterns
    if (message.includes("authentication") || message.includes("auth failed")) {
      return "AUTH_FAILED"
    }

    if (message.includes("network") || message.includes("connection")) {
      return "NETWORK_ERROR"
    }

    if (message.includes("API") || message.includes("request failed")) {
      return "API_ERROR"
    }

    if (message.includes("validation") || message.includes("invalid input")) {
      return "VALIDATION_ERROR"
    }

    if (level === "error") {
      return "UNKNOWN_ERROR"
    }

    return undefined
  }

  private getContext(): string {
    try {
      return typeof window !== "undefined" ? window.location.pathname : "server"
    } catch (e) {
      return "unknown"
    }
  }

  private getSessionId(): string {
    try {
      if (typeof window === "undefined") return `server_${Date.now()}`

      let sessionId = sessionStorage.getItem("session_id")
      if (!sessionId) {
        sessionId = `session_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
        sessionStorage.setItem("session_id", sessionId)
      }
      return sessionId
    } catch (e) {
      return `session_${Date.now()}`
    }
  }

  private storeLog(entry: LogEntry): void {
    try {
      this.logStorage.push(entry)
      if (this.logStorage.length > this.maxStoredLogs) {
        this.logStorage.shift()
      }
    } catch (error) {
      // Fallback to console if storage fails
      console.error("Failed to store log", error)
    }
  }

  private consoleLog(entry: LogEntry): void {
    if (!this.consoleEnabled) return

    try {
      const formattedMessage = `[${entry.timestamp}] [${entry.level.toUpperCase()}]${entry.errorCode ? ` [${entry.errorCode}]` : ""} ${entry.message}`

      switch (entry.level) {
        case "debug":
          console.debug(formattedMessage, entry.data || "")
          break
        case "info":
          console.info(formattedMessage, entry.data || "")
          break
        case "warn":
          console.warn(formattedMessage, entry.data || "")
          break
        case "error":
          console.error(formattedMessage, entry.data || "")
          if (entry.stack) {
            console.error(entry.stack)
          }
          break
      }
    } catch (error) {
      // Last resort fallback
      console.error("Logger failed:", error)
    }
  }

  private async sendToServer(entry: LogEntry): Promise<void> {
    if (entry.level === "error" || entry.level === "warn") {
      try {
        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

        await fetch(this.serverLogEndpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(entry),
          signal: controller.signal,
        })

        clearTimeout(timeoutId)
      } catch (e) {
        // Silently fail if server logging fails
        console.error("Failed to send log to server", e)
      }
    }
  }

  public debug(message: string, data?: any): void {
    try {
      const entry = this.createLogEntry("debug", message, data)
      this.storeLog(entry)
      this.consoleLog(entry)
    } catch (error) {
      console.error("Logger.debug failed:", error)
    }
  }

  public info(message: string, data?: any): void {
    try {
      const entry = this.createLogEntry("info", message, data)
      this.storeLog(entry)
      this.consoleLog(entry)
    } catch (error) {
      console.error("Logger.info failed:", error)
    }
  }

  public warn(message: string, data?: any): void {
    try {
      const entry = this.createLogEntry("warn", message, data)
      this.storeLog(entry)
      this.consoleLog(entry)
      this.sendToServer(entry)
    } catch (error) {
      console.error("Logger.warn failed:", error)
    }
  }

  public error(message: string, data?: any): void {
    try {
      const entry = this.createLogEntry("error", message, data)
      this.storeLog(entry)
      this.consoleLog(entry)
      this.sendToServer(entry)
    } catch (error) {
      console.error("Logger.error failed:", error)
    }
  }

  public getLogs(): LogEntry[] {
    return [...this.logStorage]
  }

  public clearLogs(): void {
    this.logStorage = []
  }

  public setConsoleEnabled(enabled: boolean): void {
    this.consoleEnabled = enabled
  }

  public setServerLogEndpoint(endpoint: string): void {
    this.serverLogEndpoint = endpoint
  }

  public getErrorDescription(errorCode: string): string {
    return this.errorCodes[errorCode] || "Unknown error"
  }
}

export const logger = Logger.getInstance()

