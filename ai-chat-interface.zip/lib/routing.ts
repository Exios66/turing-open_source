"use client"

import { useRouter, usePathname, useSearchParams } from "next/navigation"
import { useMemo } from "react"
import { logger } from "./logger"

export type RouteParams = Record<string, string | number | boolean>
export type QueryParams = Record<string, string | number | boolean | string[]>

export function useRouting() {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const query = useMemo(() => {
    const params: Record<string, string | string[]> = {}
    searchParams.forEach((value, key) => {
      const existing = params[key]
      if (existing) {
        if (Array.isArray(existing)) {
          existing.push(value)
        } else {
          params[key] = [existing, value]
        }
      } else {
        params[key] = value
      }
    })
    return params
  }, [searchParams])

  const navigate = (path: string, options?: { replace?: boolean }) => {
    logger.debug("Navigation", { from: pathname, to: path })
    if (options?.replace) {
      router.replace(path)
    } else {
      router.push(path)
    }
  }

  const navigateWithQuery = (path: string, queryParams: QueryParams, options?: { replace?: boolean }) => {
    const url = new URL(path, window.location.origin)

    Object.entries(queryParams).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        value.forEach((v) => url.searchParams.append(key, String(v)))
      } else if (value !== undefined && value !== null) {
        url.searchParams.append(key, String(value))
      }
    })

    logger.debug("Navigation with query", { from: pathname, to: url.pathname + url.search })

    if (options?.replace) {
      router.replace(url.pathname + url.search)
    } else {
      router.push(url.pathname + url.search)
    }
  }

  const updateQuery = (newParams: QueryParams, options?: { replace?: boolean }) => {
    const url = new URL(pathname, window.location.origin)

    // First, add all existing params
    searchParams.forEach((value, key) => {
      url.searchParams.append(key, value)
    })

    // Then update with new params
    Object.entries(newParams).forEach(([key, value]) => {
      // Remove existing values for this key
      url.searchParams.delete(key)

      // Add new values
      if (Array.isArray(value)) {
        value.forEach((v) => url.searchParams.append(key, String(v)))
      } else if (value !== undefined && value !== null) {
        url.searchParams.append(key, String(value))
      }
    })

    logger.debug("Query update", { from: pathname + "?" + searchParams.toString(), to: url.pathname + url.search })

    if (options?.replace) {
      router.replace(url.pathname + url.search)
    } else {
      router.push(url.pathname + url.search)
    }
  }

  return {
    pathname,
    query,
    navigate,
    navigateWithQuery,
    updateQuery,
    back: router.back,
    forward: router.forward,
  }
}

