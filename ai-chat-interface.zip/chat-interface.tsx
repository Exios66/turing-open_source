"use client"

import { useState, useRef, useEffect } from "react"
import { useChat } from "ai/react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Copy, Download, ThumbsUp, ThumbsDown, Send, Mic, MicOff } from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "@/components/ui/use-toast"

export default function ChatInterface() {
  const [isRecording, setIsRecording] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    onFinish: () => {
      // Scroll to bottom when new message arrives
      setTimeout(() => scrollToBottom(), 100)
    },
  })

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector("[data-radix-scroll-area-viewport]")
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight
      }
    }
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Handle errors
  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: error.message || "Something went wrong",
        variant: "destructive",
      })
    }
  }, [error])

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content)
    toast({
      title: "Copied to clipboard",
      description: "Message content has been copied to clipboard",
    })
  }

  const handleDownload = (content: string) => {
    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `chat-message-${new Date().toISOString().slice(0, 10)}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast({
      title: "Downloaded",
      description: "Message content has been downloaded",
    })
  }

  const handleFeedback = (type: "positive" | "negative", messageId: string) => {
    // In a real app, you would send this feedback to your backend
    toast({
      title: type === "positive" ? "Positive feedback sent" : "Negative feedback sent",
      description: `Thank you for your feedback on message ${messageId.slice(0, 8)}`,
    })
  }

  const toggleRecording = () => {
    // In a real app, you would implement speech-to-text functionality
    setIsRecording(!isRecording)
    if (!isRecording) {
      toast({
        title: "Recording started",
        description: "Voice recording is now active",
      })
    } else {
      toast({
        title: "Recording stopped",
        description: "Voice recording has ended",
      })
    }
  }

  const formatTimestamp = () => {
    const now = new Date()
    return now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
  }

  return (
    <div className="flex-1 flex flex-col">
      <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full min-h-[300px]">
              <div className="text-center space-y-2">
                <h3 className="text-lg font-medium">Welcome to GenerativeAgent</h3>
                <p className="text-sm text-muted-foreground">Start a conversation to get assistance</p>
              </div>
            </div>
          ) : (
            messages.map((message) => (
              <div key={message.id} className={cn("flex gap-2 max-w-[80%]", message.role === "user" && "ml-auto")}>
                {message.role === "assistant" && <div className="h-8 w-8 rounded-full bg-primary flex-shrink-0" />}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">
                      {message.role === "assistant" ? "GenerativeAgent" : "You"}
                    </span>
                    <span className="text-sm text-muted-foreground">{formatTimestamp()}</span>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  </div>
                  {message.role === "assistant" && (
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleCopy(message.content)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleDownload(message.content)}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleFeedback("positive", message.id)}
                      >
                        <ThumbsUp className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleFeedback("negative", message.id)}
                      >
                        <ThumbsDown className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
          {isLoading && (
            <div className="flex gap-2 max-w-[80%]">
              <div className="h-8 w-8 rounded-full bg-primary flex-shrink-0" />
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">GenerativeAgent</span>
                  <span className="text-sm text-muted-foreground">{formatTimestamp()}</span>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <div className="flex space-x-2">
                    <div
                      className="w-2 h-2 rounded-full bg-primary animate-bounce"
                      style={{ animationDelay: "0ms" }}
                    ></div>
                    <div
                      className="w-2 h-2 rounded-full bg-primary animate-bounce"
                      style={{ animationDelay: "150ms" }}
                    ></div>
                    <div
                      className="w-2 h-2 rounded-full bg-primary animate-bounce"
                      style={{ animationDelay: "300ms" }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
      <div className="p-4 border-t">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Textarea
            placeholder="Type a message as a customer"
            value={input}
            onChange={handleInputChange}
            className="min-h-[44px] max-h-32"
            disabled={isLoading}
          />
          <div className="flex flex-col gap-2">
            <Button type="button" variant="outline" size="icon" className="h-10 w-10" onClick={toggleRecording}>
              {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </Button>
            <Button type="submit" className="h-10 w-10 p-0" disabled={isLoading || input.trim() === ""}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}

