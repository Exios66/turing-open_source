"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { useChat } from "ai/react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Copy, Download, ThumbsUp, ThumbsDown, Send, Mic, MicOff, Settings, AlertCircle, RefreshCw } from "lucide-react"
import { cn } from "@/lib/utils"
import { useApiProviders } from "@/lib/api-providers"
import { useNotifications } from "@/components/ui/notification"
import { logger } from "@/lib/logger"
import { useRouting } from "@/lib/routing"
import { Modal } from "@/components/ui/modal"
import { Progress } from "@/components/ui/progress"
import ErrorBoundary from "@/components/error-boundary"

export default function ChatInterface() {
  const [isRecording, setIsRecording] = useState(false)
  const [showApiWarning, setShowApiWarning] = useState(false)
  const [showMessageDetails, setShowMessageDetails] = useState<string | null>(null)
  const [retryCount, setRetryCount] = useState(0)
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const { activeProvider, activeConfig, hasAnyConfig } = useApiProviders()
  const { showNotification } = useNotifications()
  const { navigate } = useRouting()

  // Check if API is configured
  useEffect(() => {
    if (!hasAnyConfig) {
      setShowApiWarning(true)
      logger.warn("No API provider configured", { timestamp: new Date().toISOString() })
    }
  }, [hasAnyConfig])

  const handleError = useCallback(
    (error: Error) => {
      logger.error("Chat error", {
        error: error.message,
        provider: activeProvider,
        timestamp: new Date().toISOString(),
        retryCount,
      })

      showNotification({
        type: "error",
        title: "Error",
        message: error.message || "Something went wrong with the chat request",
      })

      // Auto-retry for network errors, up to 3 times
      if (error.message.includes("network") && retryCount < 3) {
        const timeout = setTimeout(
          () => {
            setRetryCount((prev) => prev + 1)
            reload()
          },
          2000 * (retryCount + 1),
        ) // Exponential backoff

        return () => clearTimeout(timeout)
      }
    },
    [activeProvider, retryCount, showNotification],
  )

  const { messages, input, handleInputChange, handleSubmit, isLoading, error, reload, stop } = useChat({
    api: "/api/chat",
    body: activeConfig
      ? {
          provider: activeProvider,
          model: activeConfig.defaultModel,
          apiKey: activeConfig.apiKey,
          baseUrl: activeConfig.baseUrl,
        }
      : undefined,
    onError: handleError,
    onFinish: () => {
      // Reset retry count on successful completion
      setRetryCount(0)

      // Scroll to bottom when new message arrives
      setTimeout(() => scrollToBottom(), 100)
      logger.info("Chat message received", {
        messageCount: messages.length + 1,
        provider: activeProvider,
        timestamp: new Date().toISOString(),
      })
    },
  })

  const scrollToBottom = useCallback(() => {
    try {
      if (scrollAreaRef.current) {
        const scrollContainer = scrollAreaRef.current.querySelector("[data-radix-scroll-area-viewport]")
        if (scrollContainer) {
          scrollContainer.scrollTop = scrollContainer.scrollHeight
        }
      }
    } catch (error) {
      logger.error("Error scrolling to bottom", {
        error: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString(),
      })
    }
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages, scrollToBottom])

  // Handle errors
  useEffect(() => {
    if (error) {
      handleError(error)
    }
  }, [error, handleError])

  const handleCopy = useCallback(
    (content: string) => {
      try {
        navigator.clipboard.writeText(content)
        showNotification({
          type: "success",
          title: "Copied to clipboard",
          message: "Message content has been copied to clipboard",
        })
        logger.info("Message copied to clipboard", { timestamp: new Date().toISOString() })
      } catch (error) {
        logger.error("Failed to copy to clipboard", {
          error: error instanceof Error ? error.message : String(error),
          timestamp: new Date().toISOString(),
        })
        showNotification({
          type: "error",
          title: "Copy failed",
          message: "Failed to copy message to clipboard",
        })
      }
    },
    [showNotification],
  )

  const handleDownload = useCallback(
    (content: string) => {
      try {
        const blob = new Blob([content], { type: "text/plain" })
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `chat-message-${new Date().toISOString().slice(0, 10)}.txt`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(url)

        showNotification({
          type: "success",
          title: "Downloaded",
          message: "Message content has been downloaded",
        })
        logger.info("Message downloaded", { timestamp: new Date().toISOString() })
      } catch (error) {
        logger.error("Failed to download message", {
          error: error instanceof Error ? error.message : String(error),
          timestamp: new Date().toISOString(),
        })
        showNotification({
          type: "error",
          title: "Download failed",
          message: "Failed to download message content",
        })
      }
    },
    [showNotification],
  )

  const handleFeedback = useCallback(
    (type: "positive" | "negative", messageId: string) => {
      try {
        // In a real app, you would send this feedback to your backend
        showNotification({
          type: type === "positive" ? "success" : "info",
          title: type === "positive" ? "Positive feedback sent" : "Negative feedback sent",
          message: `Thank you for your feedback on message ${messageId.slice(0, 8)}`,
        })
        logger.info("Feedback submitted", {
          type,
          messageId,
          timestamp: new Date().toISOString(),
        })
      } catch (error) {
        logger.error("Failed to submit feedback", {
          error: error instanceof Error ? error.message : String(error),
          type,
          messageId,
          timestamp: new Date().toISOString(),
        })
        showNotification({
          type: "error",
          title: "Feedback failed",
          message: "Failed to submit feedback",
        })
      }
    },
    [showNotification],
  )

  const toggleRecording = useCallback(() => {
    try {
      // In a real app, you would implement speech-to-text functionality
      setIsRecording(!isRecording)
      if (!isRecording) {
        showNotification({
          type: "info",
          title: "Recording started",
          message: "Voice recording is now active",
        })
        logger.info("Voice recording started", { timestamp: new Date().toISOString() })
      } else {
        showNotification({
          type: "info",
          title: "Recording stopped",
          message: "Voice recording has ended",
        })
        logger.info("Voice recording stopped", { timestamp: new Date().toISOString() })
      }
    } catch (error) {
      logger.error("Error toggling recording", {
        error: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString(),
      })
      showNotification({
        type: "error",
        title: "Recording error",
        message: "Failed to toggle recording state",
      })
    }
  }, [isRecording, showNotification])

  const formatTimestamp = () => {
    const now = new Date()
    return now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
  }

  const handleConfigureAPI = useCallback(() => {
    navigate("/settings")
    logger.info("Navigated to settings page", { timestamp: new Date().toISOString() })
  }, [navigate])

  const handleRetry = useCallback(() => {
    try {
      reload()
      logger.info("Retrying message generation", { timestamp: new Date().toISOString() })
    } catch (error) {
      logger.error("Failed to retry message generation", {
        error: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString(),
      })
      showNotification({
        type: "error",
        title: "Retry failed",
        message: "Failed to retry message generation",
      })
    }
  }, [reload, showNotification])

  const handleShowMessageDetails = useCallback((messageId: string) => {
    setShowMessageDetails(messageId)
  }, [])

  return (
    <ErrorBoundary>
      <div className="flex-1 flex flex-col">
        <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
          <div className="space-y-4">
            {messages.length === 0 ? (
              <div className="flex items-center justify-center h-full min-h-[300px]">
                <div className="text-center space-y-2">
                  <h3 className="text-lg font-medium">Welcome to GenerativeAgent</h3>
                  <p className="text-sm text-muted-foreground">Start a conversation to get assistance</p>
                  {activeConfig && (
                    <div className="mt-4 text-sm text-muted-foreground">
                      Using {activeProvider} with model {activeConfig.defaultModel}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              messages.map((message) => (
                <div key={message.id} className={cn("flex gap-2 max-w-[80%]", message.role === "user" && "ml-auto")}>
                  {message.role === "assistant" && <div className="h-8 w-8 rounded-full bg-primary flex-shrink-0" />}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">
                        {message.role === "assistant" ? "GenerativeAgent" : "You"}
                      </span>
                      <span className="text-sm text-muted-foreground">{formatTimestamp()}</span>
                    </div>
                    <div
                      className="p-3 bg-muted/50 rounded-lg cursor-pointer hover:bg-muted/70 transition-colors"
                      onClick={() => message.role === "assistant" && handleShowMessageDetails(message.id)}
                    >
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>
                    {message.role === "assistant" && (
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleCopy(message.content)}
                        >
                          <Copy className="h-4 w-4" />
                          <span className="sr-only">Copy</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleDownload(message.content)}
                        >
                          <Download className="h-4 w-4" />
                          <span className="sr-only">Download</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleFeedback("positive", message.id)}
                        >
                          <ThumbsUp className="h-4 w-4" />
                          <span className="sr-only">Positive feedback</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleFeedback("negative", message.id)}
                        >
                          <ThumbsDown className="h-4 w-4" />
                          <span className="sr-only">Negative feedback</span>
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 ml-auto" onClick={handleRetry}>
                          <RefreshCw className="h-4 w-4" />
                          <span className="sr-only">Retry</span>
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex gap-2 max-w-[80%]">
                <div className="h-8 w-8 rounded-full bg-primary flex-shrink-0" />
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">GenerativeAgent</span>
                    <span className="text-sm text-muted-foreground">{formatTimestamp()}</span>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="flex space-x-2">
                      <div
                        className="w-2 h-2 rounded-full bg-primary animate-bounce"
                        style={{ animationDelay: "0ms" }}
                      ></div>
                      <div
                        className="w-2 h-2 rounded-full bg-primary animate-bounce"
                        style={{ animationDelay: "150ms" }}
                      ></div>
                      <div
                        className="w-2 h-2 rounded-full bg-primary animate-bounce"
                        style={{ animationDelay: "300ms" }}
                      ></div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs"
                      onClick={() => {
                        stop()
                        logger.info("Message generation stopped by user", { timestamp: new Date().toISOString() })
                      }}
                    >
                      Stop generating
                    </Button>
                    <div className="ml-2 flex-1">
                      <Progress value={45} className="h-1" />
                    </div>
                  </div>
                </div>
              </div>
            )}
            {error && !isLoading && (
              <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-md flex items-center">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                <p className="text-sm text-red-700 dark:text-red-300 mr-2">
                  {error.message || "An error occurred while generating the response"}
                </p>
                <Button variant="outline" size="sm" onClick={handleRetry} className="ml-auto flex-shrink-0">
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Retry
                </Button>
              </div>
            )}
          </div>
        </ScrollArea>
        <div className="p-4 border-t">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <Textarea
              placeholder="Type a message as a customer"
              value={input}
              onChange={handleInputChange}
              className="min-h-[44px] max-h-32"
              disabled={isLoading || !hasAnyConfig}
            />
            <div className="flex flex-col gap-2">
              <Button
                type="button"
                variant="outline"
                size="icon"
                className="h-10 w-10"
                onClick={toggleRecording}
                disabled={!hasAnyConfig}
              >
                {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
              <Button
                type="submit"
                className="h-10 w-10 p-0"
                disabled={isLoading || input.trim() === "" || !hasAnyConfig}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </form>

          {!hasAnyConfig && (
            <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-md flex items-center">
              <AlertCircle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0" />
              <p className="text-sm text-yellow-700 dark:text-yellow-300 mr-2">
                No API provider configured. You need to configure an API provider to use the chat.
              </p>
              <Button variant="outline" size="sm" onClick={handleConfigureAPI} className="ml-auto flex-shrink-0">
                <Settings className="h-4 w-4 mr-1" />
                Configure API
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* API Configuration Warning Modal */}
      <Modal
        isOpen={showApiWarning}
        onClose={() => setShowApiWarning(false)}
        title="API Configuration Required"
        description="You need to configure an API provider to use the chat functionality."
      >
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            This application supports multiple AI providers including OpenAI, Anthropic, Google, and more. You need to
            configure at least one provider with your API key to start using the chat.
          </p>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowApiWarning(false)}>
              Later
            </Button>
            <Button
              onClick={() => {
                setShowApiWarning(false)
                handleConfigureAPI()
              }}
            >
              Configure Now
            </Button>
          </div>
        </div>
      </Modal>

      {/* Message Details Modal */}
      {showMessageDetails && (
        <Modal
          isOpen={!!showMessageDetails}
          onClose={() => setShowMessageDetails(null)}
          title="Message Details"
          className="max-w-2xl"
        >
          <div className="space-y-4">
            {messages.find((m) => m.id === showMessageDetails)?.content && (
              <>
                <div className="p-4 bg-muted/30 rounded-md max-h-[400px] overflow-y-auto">
                  <pre className="whitespace-pre-wrap text-sm">
                    {messages.find((m) => m.id === showMessageDetails)?.content}
                  </pre>
                </div>
                <div className="flex justify-between">
                  <div className="text-sm text-muted-foreground">
                    <p>Provider: {activeProvider}</p>
                    <p>Model: {activeConfig?.defaultModel}</p>
                    <p>Generated: {new Date().toLocaleString()}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const content = messages.find((m) => m.id === showMessageDetails)?.content || ""
                        handleCopy(content)
                      }}
                    >
                      <Copy className="h-4 w-4 mr-1" />
                      Copy
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const content = messages.find((m) => m.id === showMessageDetails)?.content || ""
                        handleDownload(content)
                      }}
                    >
                      <Download className="h-4 w-4 mr-1" />
                      Download
                    </Button>
                  </div>
                </div>
              </>
            )}
          </div>
        </Modal>
      )}
    </ErrorBoundary>
  )
}

